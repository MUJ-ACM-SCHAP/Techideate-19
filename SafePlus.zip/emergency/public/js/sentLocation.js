
var pusher = new Pusher('bc1b02f35d3e8b00ccfa', {
    cluster: 'ap2',
    encrypted: true
  });

var channel = pusher.subscribe('private-alpha');

channel.bind('client-location', function(data) {
    console.log(data);
    // marker.setPosition(data);
    // marker.setPosition({lat:parseFloat(data.lat),lng:parseFloat(data.long)})
    marker.setPosition({lat: data.lati, lng: data.longi});
  });


var marker;
function initMap() {
  var manipal = {lat: 26.8420898, lng: 75.5623966};
  var map = new google.maps.Map(document.getElementById('map'), {zoom: 10, center: manipal});
  marker = new google.maps.Marker({position: manipal, map: map});
}


