var pusher = new Pusher('bc1b02f35d3e8b00ccfa', {
    cluster: 'ap2',
    encrypted: true
  });
  var channel = pusher.subscribe('private-alpha');

  channel.bind('pusher:subscription_succeeded', function() {
    var locationWatcher = navigator.geolocation.watchPosition(function(pos){
    var location =
        {
            lati : pos.coords.latitude,
            longi : pos.coords.longitude
        }
        var triggered = channel.trigger('client-location', location);
    });

  });

// let map;
// function initMap() {
// map = new google.maps.Map(document.getElementById('map'), {
//     center: {lat: 26.8420898, lng: 75.5623966},
//     zoom: 15
// });
// if ('geolocation' in navigator) {
//     const currentLocation = navigator.geolocation.getCurrentPosition(function (position) {
//     const nowLocation = {
//         lat: position.coords.latitude,
//         lng: position.coords.longitude
//     }
//     const marker = new google.maps.Marker({position: nowLocation, map: map});
//     console.log("location set")
//     });
// }

// };


// function triggerLocationChangeEvents (channel, location) {
// // update myLastLocation
// myLastKnownLocation = location;
// channel.trigger('client-location', location);
// }

// function createMyLocationChannel (name) {
// var myLocationChannel = pusher.subscribe('private-' + name);
// myLocationChannel.bind('pusher:subscription_succeeded', function() {
//     locationWatcher = navigator.geolocation.watchPosition(function(position) {
//     let location = {
//         lat: position.coords.latitude,
//         lng: position.coords.longitude
//     };
//     triggerLocationChangeEvents(myLocationChannel, location);
//     });

//     // also start a setInterval to keep sending the location every 5 secs
//     sendLocationInterval = setInterval(function () {
//     myLocationChannel.trigger('client-location', myLastKnownLocation)
//     }, 5000);
// });
// }
// createMyLocationChannel("alpha")
channel.bind('pusher:subscription_succeeded', function() {
  var locationWatcher = navigator.geolocation.watchPosition(function(pos){
  var location =
      {
          lati : pos.coords.latitude,
          longi : pos.coords.longitude
      }
      var triggered = channel.trigger('client-location', location);
  });

});