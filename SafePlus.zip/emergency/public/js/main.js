console.log("main.js is here")

if('serviceWorker' in navigator){
    window.addEventListener('load',() => {
        navigator.serviceWorker.register('../sw_cached_site.js',{
            scope: '/'
          })
        .then(req => console.log('Service Worker: Registered'))
        .catch(err => console.log(`Service Worker error: ${err}`))
    })
}
