
const latitudeInput = document.getElementById("latitude");
const longitudeInput = document.getElementById("longitude");
const EmergencyButton = document.getElementById("emergencyButton")
// const EmergencyContact = document.getElementById("emergencyContact")
// const contactSelect = document.getElementById("contact")
EmergencyButton.addEventListener('click',function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(addPosition);
    } else {
      alert("Location not supported");
    }
  })
async function addPosition(position) {
    await latitudeInput.setAttribute("value", position.coords.latitude);
    await longitudeInput.setAttribute("value", position.coords.longitude);
    // defaultLink = await `https://api.whatsapp.com/send?phone=91${contactSelect.options[0].value}&text=Pleasehelpme!https://www.google.com/maps?daddr=${latitudeInput.value},${longitudeInput.value}`
    // await console.log(defaultLink)
    // await EmergencyContact.setAttribute('href',defaultLink)
  }
// function changeLink(){
//     Link = "https://api.whatsapp.com/send?phone=91"+ contactSelect.value + "&text=Please help me! https://www.google.com/maps?daddr=" + latitudeInput.value + "," + longitudeInput.value;
//     EmergencyContact.setAttribute('href',Link)
//   }