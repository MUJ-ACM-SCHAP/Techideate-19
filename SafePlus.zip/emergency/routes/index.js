const express = require("express");
const router = express.Router();
const { ensureAuthenticated } = require("../config/auth");
const EmergencyController = require("../controllers/emergency");
const DashboardController = require("../controllers/dashboard");
const NewsController = require("../controllers/news")
const LocationController = require('../controllers/mylocation')

// const nodemailer = require("nodemailer");
// const ReminderController = require("../controllers/reminder");

router.get("/", (req, res) => {
  res.render("home")
});
router.get("/dashboard", ensureAuthenticated, DashboardController.getDashboard);
router.get("/dashboard", ensureAuthenticated, DashboardController.getDashboard);
router.post(
  "/dashboard",
  ensureAuthenticated,
  DashboardController.postDashboard
);

router.get(
  "/emergencyContactForm",
  ensureAuthenticated,
  DashboardController.getEmergencyContactForm
);

router.get("/emergency", ensureAuthenticated, EmergencyController.getEmergency);

router.post("/news",ensureAuthenticated,NewsController.postNews)

router.post("/emergency",ensureAuthenticated,EmergencyController.postEmergency);

router.get('/mylocation',LocationController.getLocation)

module.exports = router;

// Whatever near me feature
// router.post('/home',(req,res)=>{
//     console.log(req.body)
//     res.redirect("https://www.google.com/maps/search/"+ req.body.pincode+"+hospitals+near+me");
// })

// router.get('/about',(req,res)=>{
//     res.render('about');
// });
// router.get('/contact',(req,res)=>{
//     res.render('contact')
// });
// //
// router.post('/reminder',ensureAuthenticated,ReminderController.postreminder)
// // router.post('/emergency',ensureAuthenticated,EmergencyController.postemergency)

// router.get('/medicinelist', ensureAuthenticated, (req, res) =>
//     res.render("medicinelist", {
//         user: req.user
//     }));
// router.get("/reminder", ensureAuthenticated, (req, res) =>
//   res.render("reminder", {
//     user: req.user
//   })
// );
