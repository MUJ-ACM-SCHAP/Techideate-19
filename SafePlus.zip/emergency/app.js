const express = require("express");
const mongoose = require("mongoose");
const flash = require("connect-flash");
const session = require("express-session");
const passport = require("passport");
var Pusher = require('pusher');
// const bodyParser = require('body-parser');
var pusher = new Pusher({
  appId: '734920',
  key: 'bc1b02f35d3e8b00ccfa',
  secret: 'ab14c3ab250258b3c9cf',
  cluster: 'ap2',
  encrypted: true
});

// var pusher = new Pusher({
//   appId: 'INSERT_YOUR_APP_ID_HERE',
//   key: 'INSERT_YOUR_KEY_HERE',
//   secret:  'INSERT_YOUR_SECRET_HERE',
//   cluster: '<INSERT_PUSHER_CLUSTER_HERE>'
// });


//Db config;
const db = require("./config/keys").MongoURI;
require("./config/passport")(passport);

// connect to mongo

mongoose
  .connect(db, { useNewUrlParser: true })
  .then(() => console.log("MongoDB connected..."))
  .catch(err => console.log(err));

const app = express();
app.use(express.static("public"));
// font awesome
app.use('/fonts', express.static('./node_modules/font-awesome/fonts'))

// Ejs
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
// app.use(bodyParser.urlencoded({ extended: false }))

// Express Session
app.use(
  session({
    secret: "secret",
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 365 * 24 * 60 * 60 * 1000 }
  })
);

app.use(passport.initialize());
app.use(passport.session());

app.use(flash());

// Global Vars()
app.use((req, res, next) => {
  res.locals.success_msg = req.flash("success_msg");
  res.locals.error_msg = req.flash("error_msg");
  res.locals.error = req.flash("error");
  next();
});

const PORT = process.env.PORT || 5000;

//routes

app.use("/", require("./routes/index"));
app.use("/users", require("./routes/users"));
app.post('/pusher/auth', function(req, res) {
  var socketId = req.body.socket_id;
  var channel = req.body.channel_name;
  var auth = pusher.authenticate(socketId, channel);
  res.send(auth);
});

app.listen(PORT, console.log(`Server started on Port ${PORT}`));


// app.get('*', function(req, res) {
//   res.redirect('https://' + req.headers.host + req.url);
// })
