const mongoose = require('mongoose');

const emergencyContactSchema = new mongoose.Schema({
    contactname: {
        type: String,
        required: true
    },
    contactemail: {
        type: String,
        required: true
    },
    contactphone: {
        type: String,
        required: true
    }
});
// const emergencyContact = mongoose.model('emergencyContact', emergencyContactSchema);


module.exports = emergencyContactSchema;