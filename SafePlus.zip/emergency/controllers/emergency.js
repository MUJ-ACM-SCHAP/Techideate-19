// const User = require("../models/User");
const nodemailer = require("nodemailer");
const Myusername = require("../config/keys").SendGridUsername;
const Mypassword = require("../config/keys").SendGridPassword;

module.exports.getEmergency = (req, res) => {
  res.render("emergency");
};


module.exports.postEmergency = (req, res) => {

  console.log(req.user);
  console.log(req.body);

  const smtpTransport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: Myusername,
        pass: Mypassword
    }
});


  const { contact, latitude, longitude } = req.body;

  const emergencyContact = req.user.emergencyContact || req.session.user.emergencyContact;

  let choosenContact = 0;

  emergencyContact.forEach((element) => {

    const mailOptions = {
      to: element.contactemail,
      from: 'thesarthakarora@gmail.com',
      subject: 'Emergency  for '+ req.user.name,
      text: "Hey " + element.contactname + " there is an emergency!!!!, Please help "+ req.user.name + ". The Google maps link to reach him is https://www.google.com/maps?daddr="+ latitude +"," + longitude
  };
  smtpTransport.sendMail(mailOptions);
  console.log("mail sent")

  });



  const link = "https://api.whatsapp.com/send?phone=91" + contact + "&text=Pleasehelpme!https://safeplus1.herokuapp.com/mylocation";
  // const link = "https://api.whatsapp.com/send?phone=91" + contact + "&text=Pleasehelpme!/mylocation";

  res.render('LocationShare',{link,contact})

  // change contact to name later version
  // res.redirect(link)
};
