module.exports.getLocation = (req, res) => {
    res.render("SentLocation")
}