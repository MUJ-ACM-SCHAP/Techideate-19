const User = require("../models/User");
const nodemailer = require("nodemailer");
const Myusername = require("../config/keys").SendGridUsername;
const Mypassword = require("../config/keys").SendGridPassword;
// const emergencyContactSchema = require("../models/emergencyContact");
module.exports.getDashboard = (req, res) => {
  console.log(req.user);
  console.log(req.session);
  const { name, email, emergencyContact } = req.user;
  if (emergencyContact.length > 0) {
    req.session.user = req.user
    res.render("dashboard", {
      user: req.user || req.session.user
    });
  } else {
    res.redirect("/emergencyContactForm");
  }
};
module.exports.postDashboard = (req, res) => {
  console.log(req.body);
  // User Object
  const { name, email, emergencyContact } = req.user || req.session.user;
  //Emergency Contact Object
  const { contactname, contactemail, contactphone } = req.body;

  let errors = [];

  if (!contactname || !contactemail || !contactphone) {
    errors.push({
      msg: "PLease fill in all fields"
    });
  }

  if (errors.length > 0) {
    res.render("emergencyContactForm", {
      errors,
      contactname,
      contactemail,
      contactphone
    });
  } else {
    User.findOne({ email: email })
      .then(user => {
        user.emergencyContact.push({
          contactname,
          contactemail,
          contactphone
        });
        user
          .save()
          .then(user => {
            const msg = contactname + " is now added as an Emergency Contact!";
            req.flash("success_msg", msg);
            res.redirect("/dashboard");
          })
          .catch(err => console.log(err));
      })
      .catch(err => console.log(err));
  }
};
module.exports.getEmergencyContactForm = (req, res) => {
  console.log(req.user);
  res.render("emergencyContactForm");
};
