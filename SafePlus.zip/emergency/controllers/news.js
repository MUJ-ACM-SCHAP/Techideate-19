const request = require('request');


module.exports.postNews = (req,res) => {
    const options = {
        url : "https://newsapi.org/v2/everything?apiKey=fbefc601f21e4742ab074cf42a8fb2a1",
        qs : {
            q : req.body.search
        }
    }
    request(options,(err,resp,body)=>{
    //console.log(resp.status);
    console.log(JSON.parse(body).articles.length);
    res.render('news', {articles : JSON.parse(body).articles});
})
}
