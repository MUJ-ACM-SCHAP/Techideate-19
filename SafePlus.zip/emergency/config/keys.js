module.exports = {
  MongoURI: "mongodb+srv://thesarthakarora:warmonger@emergency-jz0hk.mongodb.net/test?retryWrites=true",
  SendGridUsername:"thesarthakarora@gmail.com",
  SendGridPassword:"wimzfsoeqxhyfkbh",
  Pusher:
    {
      appId: '734920',
      key: 'bc1b02f35d3e8b00ccfa',
      secret: 'ab14c3ab250258b3c9cf',
      cluster: 'ap2',
      encrypted: true
    }
};