# Techideate-19
The final Hackathon of the year organised by MUJ ACM SCHAP to bring together a large number of young developers and programmers. They use 24 hours to make something innovative and out of the box using a cool stack of technologies. Learning team and time management and brainstorming under time constraints which only lets the participants make a prototype. 


## Instructions:

1. Fork the repository and clone it to your PC.

2. Put your code inside the cloned repository.

3. Push it to your forked repository.

4. Create a Pull Request and we will take care of the rest.


### Github Cheat Sheet:
https://education.github.com/git-cheat-sheet-education.pdf
